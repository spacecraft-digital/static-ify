{
	"name": "Birmingham City Council",
	"icons": [
		{
			"src": "\/site\/favicon\/android-chrome-36x36.png?v=kPP6reKB8a",
			"sizes": "36x36",
			"type": "image\/png",
			"density": 0.75
		},
		{
			"src": "\/site\/favicon\/android-chrome-48x48.png?v=kPP6reKB8a",
			"sizes": "48x48",
			"type": "image\/png",
			"density": 1
		},
		{
			"src": "\/site\/favicon\/android-chrome-72x72.png?v=kPP6reKB8a",
			"sizes": "72x72",
			"type": "image\/png",
			"density": 1.5
		},
		{
			"src": "\/site\/favicon\/android-chrome-96x96.png?v=kPP6reKB8a",
			"sizes": "96x96",
			"type": "image\/png",
			"density": 2
		},
		{
			"src": "\/site\/favicon\/android-chrome-144x144.png?v=kPP6reKB8a",
			"sizes": "144x144",
			"type": "image\/png",
			"density": 3
		},
		{
			"src": "\/site\/favicon\/android-chrome-192x192.png?v=kPP6reKB8a",
			"sizes": "192x192",
			"type": "image\/png",
			"density": 4
		}
	]
}
